from django.shortcuts import render, redirect
from .forms import ContactForm
def index(request):
    return render(request, 'index.html')
def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thanks')
    else:
        form = ContactForm()
    return render(request, 'contact.html', {'form': form})
def thanks(request):
    return render(request, 'thanks.html')
