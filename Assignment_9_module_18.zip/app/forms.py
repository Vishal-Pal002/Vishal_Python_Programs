from django import forms
from .models import Contact
class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = ['name', 'email', 'message']
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': 'Your name', 'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'placeholder': 'you@example.com', 'class': 'form-control'}),
            'message': forms.Textarea(attrs={'placeholder': 'Write your message here', 'class': 'form-control', 'rows':4}),
        }
