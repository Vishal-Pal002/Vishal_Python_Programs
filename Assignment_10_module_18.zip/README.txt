Assignment_10_module_18 - Django Blog project
--------------------------------------------------
Project name: website
App name: blog

Quick setup instructions (run in your project folder):
  1. Create and activate a virtual environment:
     python -m venv venv
     source venv/bin/activate    # Linux / macOS
     venv\Scripts\activate     # Windows PowerShell/CMD

  2. Install requirements:
     pip install -r requirements.txt

  3. Apply migrations:
     python manage.py migrate

  4. Create a superuser to access admin and add posts:
     python manage.py createsuperuser

  5. Collect static (optional in development):
     python manage.py collectstatic

  6. Run development server:
     python manage.py runserver

  7. In admin (http://127.0.0.1:8000/admin/) create posts. Upload images to see thumbnails.
     Posts require a slug (auto-generated when saving in admin due to prepopulated field).

Files provided:
  - manage.py
  - website/ (Django project)
  - blog/ (Django app)
  - templates/blog/ (templates)
  - static/css/style.css
  - requirements.txt

Notes:
  - DEBUG=True for development. Change SECRET_KEY and DEBUG for production.
  - MEDIA files are served in development via settings and django.static helper.
