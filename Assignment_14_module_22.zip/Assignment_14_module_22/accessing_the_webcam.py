import cv2

cop = cv2.VideoCapture(0)

while cop.isOpened():
    _, frame = cop.read()
    cv2.imshow('frame', frame)

    if cv2.waitKey(10) == ord('z'):
        break

cop.release()
cv2.destroyAllWindows()
