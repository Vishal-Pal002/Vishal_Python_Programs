import cv2

image = cv2.imread(r"C:\Users\Vishal Pal\Open_CV\Assignment_14_module_22\highway.jpg",1)
print("Dimensions of the image:", image.shape)

width = 400
height = 400
dim = (width, height)
resized = cv2.resize(image, dim)

cv2.imshow("window", resized)
cv2.waitKey(0)
cv2.destroyAllWindows()
