import cv2

img = cv2.imread(r"C:\Users\Vishal Pal\Open_CV\Assignment_14_module_22\highway.jpg")
width = 600
height = 850
dim = (width, height)

resized = cv2.resize(img, dim)
print("Size in bytes:", img.size)

cv2.imshow("Original", resized)

#flip_0 = cv2.flip(resized, 1)
#cv2.imshow("Horizontal", flip_0)

#flip_1 = cv2.flip(resized, 0)
#cv2.imshow("Vertical", flip_1)

flip_2 = cv2.flip(resized, -1)
cv2.imshow("Horizontal & Vertical", flip_2)

cv2.waitKey(0)
cv2.destroyAllWindows()
