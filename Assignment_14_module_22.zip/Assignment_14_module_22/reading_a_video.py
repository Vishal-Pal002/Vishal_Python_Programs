import cv2

video = cv2.VideoCapture(r'C:/Users/Vishal Pal/Open_CV/Assignment_14_module_22/nature.mp4')

while video.isOpened():
    _, frame = video.read()
    frame = cv2.resize(frame, (800, 720))
    cv2.imshow('Output', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cv2.destroyAllWindows()
