import cv2

img = cv2.imread(r'C:\Users\Vishal Pal\Open_CV\Assignment_14_module_22\highway.jpg')

print('Dimensions of Original image: ', img.shape)

scale = 150

width = int(img.shape[1] * scale / 100)
height = int(img.shape[0] * scale / 100)
dim = (width, height)

resized = cv2.resize(img, dim)
print('Dimensions of Resized Image: ', resized.shape)

cv2.imshow('Resized', resized)
cv2.imshow('Original', img)

cv2.waitKey(0)
cv2.destroyAllWindows()
