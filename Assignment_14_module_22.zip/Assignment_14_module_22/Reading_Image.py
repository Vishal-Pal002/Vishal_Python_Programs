import cv2

image = cv2.imread(r"C:\Users\Vishal Pal\Open_CV\Assignment_14_module_22\highway.jpg",1)

cv2.imshow('window', image)
cv2.imwrite(r"C:\Users\Vishal Pal\Open_CV\Assignment_14_module_22\highway-1.jpg",image)

cv2.waitKey(0)
cv2.destroyAllWindows()
