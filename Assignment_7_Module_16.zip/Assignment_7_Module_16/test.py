import psycopg2

conn = psycopg2.connect(
    database="test",
    user="postgres",
    password="Vishal@0047",
    host="localhost",
    port="5432"
)
print("Database connected successfully")
conn.close()
