import socket
from tkinter import *

def send():
    message = message_box.get("1.0", END).strip()
    if message:
        chat_list.insert(END, "Client: " + message)
        client.send(message.encode())
        message_box.delete("1.0", END)

def receive():
    data = client.recv(1024).decode()
    chat_list.insert(END, "Server: " + data)

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((socket.gethostname(), 12345))
print("Connected to the server...")

root = Tk()
root.title("Client")

chat_list = Listbox(root, width=50, height=15)
chat_list.pack(padx=10, pady=10)

receive_button = Button(root, text="Recieve", width=10, command=receive)
receive_button.pack(pady=3)

send_button = Button(root, text="Send", width=10, command=send)
send_button.pack(pady=3)

message_box = Text(root, width=50, height=3)
message_box.pack(padx=10, pady=10)

root.mainloop()
