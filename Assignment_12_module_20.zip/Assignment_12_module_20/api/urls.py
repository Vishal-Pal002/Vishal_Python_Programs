from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import ArticleViewSet, article_list

router = DefaultRouter()
router.register(r'articles', ArticleViewSet, basename='article')

urlpatterns = [
    path('articles-fbv/', article_list, name='article-list-fbv'),
]

urlpatterns += router.urls
