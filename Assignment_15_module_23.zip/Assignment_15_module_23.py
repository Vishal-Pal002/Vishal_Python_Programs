from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
import time

options = Options()
options.add_argument("--start-maximized")

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)
driver.get("https://www.myntra.com")

time.sleep(3)
search_box = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.CLASS_NAME, "desktop-searchBar"))
)
search_box.clear()
search_box.send_keys("headphones")
search_box.send_keys(Keys.RETURN)

WebDriverWait(driver, 20).until(
    EC.presence_of_all_elements_located((By.CSS_SELECTOR, "li.product-base"))
)

products = driver.find_elements(By.CSS_SELECTOR, "h3.product-brand, h4.product-product")

print(f"{len(products)} products found")
for item in products[:10]:
    print("-", item.text.strip())

driver.quit()
