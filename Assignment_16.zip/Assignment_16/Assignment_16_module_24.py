from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
import time

driver = webdriver.Firefox()
driver.get('https://www.facebook.com')

time.sleep(3)
driver.find_element(By.ID, "email").send_keys("jasondaung@gmail.com")
driver.find_element(By.ID, "pass").send_keys("Jason@123")
driver.find_element(By.NAME, "login").click()

time.sleep(10)
driver.get('https://www.facebook.com')

time.sleep(5)
actions = ActionChains(driver)
actions.send_keys(Keys.ESCAPE).perform()
time.sleep(2)

post_box = driver.find_element(By.XPATH, "//span[contains(text(),'on your mind')]")
post_box.click()
time.sleep(5)

active_box = driver.find_element(By.XPATH, "//div[@role='textbox']")
active_box.send_keys("Hello! Welcome to The Project")
time.sleep(5)

buttons = driver.find_elements(By.XPATH, "//div[@aria-label='Post']")
if not buttons:
    buttons = driver.find_elements(By.XPATH, "//span[text()='Post']")
for b in buttons:
    try:
        b.click()
        break
    except:
        continue

time.sleep(5)
driver.quit()
